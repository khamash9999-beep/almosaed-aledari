import { AlertTriangle } from 'lucide-react'
import { SidebarNav } from '@/components/sidebar-nav'
import { TopBar } from '@/components/top-bar'
import { StatCards } from '@/components/stat-cards'
import { CorrespondenceLedger } from '@/components/correspondence-ledger'
import { TasksPanel } from '@/components/tasks-panel'
import { RequestsPanel } from '@/components/requests-panel'
import { AgendaPanel } from '@/components/agenda-panel'
import { WorkloadPanel } from '@/components/workload-panel'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

export default function DashboardPage() {
  return (
    <div className="flex min-h-svh">
      {/* Desktop rail */}
      <aside className="sticky top-0 hidden h-svh w-64 shrink-0 border-e border-sidebar-border lg:block">
        <SidebarNav />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar />

        <main className="flex flex-col gap-4 p-3 sm:p-5">
          <div className="flex flex-col gap-1">
            <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">
              صباح الخير، فهد
            </h1>
            <p className="text-sm leading-relaxed text-muted-foreground">
              لديك 12 معاملة بانتظار التوقيع و 9 طلبات تحتاج اعتماداً اليوم.
            </p>
          </div>

          <Alert>
            <AlertTriangle />
            <AlertTitle>5 مهام تجاوزت تاريخ الاستحقاق</AlertTitle>
            <AlertDescription>
              أقدمها مهمة تحديث جدول المناوبات المكلّف بها خالد الحربي.
            </AlertDescription>
          </Alert>

          <StatCards />

          <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            <div className="flex flex-col gap-4 xl:col-span-2">
              <CorrespondenceLedger />
              <TasksPanel />
            </div>
            <div className="flex flex-col gap-4">
              <RequestsPanel />
              <AgendaPanel />
              <WorkloadPanel />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
