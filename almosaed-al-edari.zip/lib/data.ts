export type Priority = 'عاجل' | 'مرتفع' | 'عادي'
export type TaskStatus = 'منجزة' | 'قيد التنفيذ' | 'متأخرة' | 'لم تبدأ'

export type Task = {
  id: string
  ref: string
  title: string
  department: string
  assignee: string
  due: string
  priority: Priority
  status: TaskStatus
  progress: number
}

export type CorrespondenceKind = 'وارد' | 'صادر' | 'تعميم'
export type CorrespondenceStatus =
  | 'بانتظار التوقيع'
  | 'محوّلة'
  | 'مؤرشفة'
  | 'مرتجعة'

export type Correspondence = {
  id: string
  ref: string
  kind: CorrespondenceKind
  subject: string
  party: string
  date: string
  status: CorrespondenceStatus
  priority: Priority
}

export type RequestStatus = 'بانتظار الاعتماد' | 'معتمدة' | 'مرفوضة'

export type EmployeeRequest = {
  id: string
  employee: string
  role: string
  type: string
  detail: string
  submitted: string
  status: RequestStatus
}

export type Meeting = {
  id: string
  title: string
  time: string
  duration: string
  room: string
  attendees: number
  kind: 'اجتماع' | 'عرض' | 'متابعة'
}

export const stats = [
  {
    id: 'tasks',
    label: 'مهام مفتوحة',
    value: 34,
    delta: '+6',
    trend: 'up' as const,
    caption: 'مقارنة بالأسبوع الماضي',
  },
  {
    id: 'signature',
    label: 'بانتظار التوقيع',
    value: 12,
    delta: '-3',
    trend: 'down' as const,
    caption: 'معاملات على مكتب المدير',
  },
  {
    id: 'requests',
    label: 'طلبات الموظفين',
    value: 9,
    delta: '+2',
    trend: 'up' as const,
    caption: 'تحتاج اعتماداً اليوم',
  },
  {
    id: 'overdue',
    label: 'متأخرة عن الموعد',
    value: 5,
    delta: '+1',
    trend: 'up' as const,
    caption: 'تجاوزت تاريخ الاستحقاق',
  },
]

export const tasks: Task[] = [
  {
    id: 't1',
    ref: 'TSK-2418',
    title: 'إعداد مذكرة رفع الميزانية التشغيلية للربع الثالث',
    department: 'الشؤون المالية',
    assignee: 'نورة العتيبي',
    due: '2026-08-07',
    priority: 'عاجل',
    status: 'قيد التنفيذ',
    progress: 65,
  },
  {
    id: 't2',
    ref: 'TSK-2417',
    title: 'تحديث جدول المناوبات لشهر رمضان',
    department: 'الموارد البشرية',
    assignee: 'خالد الحربي',
    due: '2026-08-06',
    priority: 'مرتفع',
    status: 'متأخرة',
    progress: 30,
  },
  {
    id: 't3',
    ref: 'TSK-2415',
    title: 'أرشفة عقود الموردين المنتهية إلكترونياً',
    department: 'المشتريات',
    assignee: 'سارة القحطاني',
    due: '2026-08-11',
    priority: 'عادي',
    status: 'قيد التنفيذ',
    progress: 45,
  },
  {
    id: 't4',
    ref: 'TSK-2412',
    title: 'صياغة رد على استفسار الجهة الرقابية',
    department: 'الشؤون القانونية',
    assignee: 'عبدالله الشمري',
    due: '2026-08-06',
    priority: 'عاجل',
    status: 'قيد التنفيذ',
    progress: 80,
  },
  {
    id: 't5',
    ref: 'TSK-2409',
    title: 'حصر احتياجات الأجهزة المكتبية للإدارات',
    department: 'الخدمات المساندة',
    assignee: 'منى الزهراني',
    due: '2026-08-14',
    priority: 'عادي',
    status: 'لم تبدأ',
    progress: 0,
  },
  {
    id: 't6',
    ref: 'TSK-2404',
    title: 'اعتماد محضر اجتماع اللجنة التنفيذية',
    department: 'مكتب المدير العام',
    assignee: 'فهد المطيري',
    due: '2026-08-05',
    priority: 'مرتفع',
    status: 'منجزة',
    progress: 100,
  },
]

export const correspondence: Correspondence[] = [
  {
    id: 'c1',
    ref: 'و/2026/1184',
    kind: 'وارد',
    subject: 'طلب موافاة ببيانات الكادر الإداري للعام المالي',
    party: 'وزارة المالية',
    date: '2026-08-05',
    status: 'بانتظار التوقيع',
    priority: 'عاجل',
  },
  {
    id: 'c2',
    ref: 'ص/2026/0932',
    kind: 'صادر',
    subject: 'تزكية مرشحين لبرنامج التطوير القيادي',
    party: 'معهد الإدارة العامة',
    date: '2026-08-04',
    status: 'محوّلة',
    priority: 'مرتفع',
  },
  {
    id: 'c3',
    ref: 'ت/2026/0071',
    kind: 'تعميم',
    subject: 'تنظيم الدوام في الأسبوع الأول من الفصل الدراسي',
    party: 'جميع الإدارات',
    date: '2026-08-04',
    status: 'مؤرشفة',
    priority: 'عادي',
  },
  {
    id: 'c4',
    ref: 'و/2026/1179',
    kind: 'وارد',
    subject: 'إشعار بتجديد ترخيص المنشأة',
    party: 'أمانة المنطقة',
    date: '2026-08-03',
    status: 'بانتظار التوقيع',
    priority: 'مرتفع',
  },
  {
    id: 'c5',
    ref: 'ص/2026/0928',
    kind: 'صادر',
    subject: 'الرد على ملاحظات المراجعة الداخلية',
    party: 'إدارة المراجعة',
    date: '2026-08-02',
    status: 'مرتجعة',
    priority: 'عاجل',
  },
  {
    id: 'c6',
    ref: 'و/2026/1170',
    kind: 'وارد',
    subject: 'دعوة لحضور ورشة الحوكمة الرقمية',
    party: 'هيئة الحكومة الرقمية',
    date: '2026-08-01',
    status: 'مؤرشفة',
    priority: 'عادي',
  },
]

export const requests: EmployeeRequest[] = [
  {
    id: 'r1',
    employee: 'ريم الدوسري',
    role: 'محللة موارد بشرية',
    type: 'إجازة اضطرارية',
    detail: '3 أيام — من 10 إلى 12 أغسطس',
    submitted: 'قبل ساعتين',
    status: 'بانتظار الاعتماد',
  },
  {
    id: 'r2',
    employee: 'ماجد العنزي',
    role: 'أمين مستودع',
    type: 'صرف سلفة',
    detail: 'سلفة مستردة على 6 أشهر',
    submitted: 'أمس',
    status: 'بانتظار الاعتماد',
  },
  {
    id: 'r3',
    employee: 'هند البلوي',
    role: 'سكرتيرة تنفيذية',
    type: 'تكليف بمهمة',
    detail: 'حضور اجتماع الفرع الشرقي',
    submitted: 'أمس',
    status: 'معتمدة',
  },
  {
    id: 'r4',
    employee: 'تركي السبيعي',
    role: 'مسؤول مشتريات',
    type: 'خطاب تعريف',
    detail: 'موجّه إلى البنك — راتب',
    submitted: 'قبل 3 أيام',
    status: 'معتمدة',
  },
  {
    id: 'r5',
    employee: 'لمى الغامدي',
    role: 'منسقة تدريب',
    type: 'تمديد إجازة',
    detail: 'يومان إضافيان',
    submitted: 'قبل 4 أيام',
    status: 'مرفوضة',
  },
]

export const meetings: Meeting[] = [
  {
    id: 'm1',
    title: 'اجتماع اللجنة التنفيذية الأسبوعي',
    time: '09:00',
    duration: '60 د',
    room: 'قاعة الاجتماعات الرئيسية',
    attendees: 8,
    kind: 'اجتماع',
  },
  {
    id: 'm2',
    title: 'عرض مؤشرات الأداء لإدارة الخدمات',
    time: '11:30',
    duration: '45 د',
    room: 'قاعة 2‑ب',
    attendees: 5,
    kind: 'عرض',
  },
  {
    id: 'm3',
    title: 'متابعة مشروع الأرشفة الإلكترونية',
    time: '13:15',
    duration: '30 د',
    room: 'عن بُعد',
    attendees: 4,
    kind: 'متابعة',
  },
  {
    id: 'm4',
    title: 'مقابلة مرشح لوظيفة محاسب أول',
    time: '15:00',
    duration: '40 د',
    room: 'مكتب الموارد البشرية',
    attendees: 3,
    kind: 'اجتماع',
  },
]

export const departmentLoad = [
  { name: 'الموارد البشرية', open: 11, total: 18 },
  { name: 'الشؤون المالية', open: 8, total: 14 },
  { name: 'المشتريات', open: 6, total: 12 },
  { name: 'الشؤون القانونية', open: 5, total: 7 },
  { name: 'الخدمات المساندة', open: 4, total: 10 },
]

export function formatDate(iso: string) {
  const [y, m, d] = iso.split('-')
  return `${d}/${m}/${y}`
}
