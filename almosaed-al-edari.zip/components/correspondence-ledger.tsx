'use client'

import { useState } from 'react'
import { ArrowLeftRight, Inbox, Send, Megaphone } from 'lucide-react'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CorrespondenceStatusBadge, PriorityBadge } from '@/components/status-badge'
import { correspondence, formatDate, type CorrespondenceKind } from '@/lib/data'
import { cn } from '@/lib/utils'

const kindIcon: Record<CorrespondenceKind, typeof Inbox> = {
  وارد: Inbox,
  صادر: Send,
  تعميم: Megaphone,
}

const filters = [
  { value: 'الكل', label: 'الكل' },
  { value: 'وارد', label: 'وارد' },
  { value: 'صادر', label: 'صادر' },
  { value: 'تعميم', label: 'تعميم' },
]

export function CorrespondenceLedger() {
  const [filter, setFilter] = useState('الكل')

  return (
    <Card>
      <CardHeader>
        <CardTitle>سجل المعاملات</CardTitle>
        <CardDescription>
          البريد الوارد والصادر والتعاميم لهذا الأسبوع
        </CardDescription>
        <CardAction>
          <Button variant="outline" size="sm">
            <ArrowLeftRight data-icon="inline-start" />
            <span className="hidden sm:inline">فتح السجل الكامل</span>
            <span className="sm:hidden">السجل</span>
          </Button>
        </CardAction>
      </CardHeader>

      <CardContent>
        <Tabs value={filter} onValueChange={setFilter}>
          <TabsList variant="line" className="mb-3 w-full justify-start">
            {filters.map((f) => (
              <TabsTrigger key={f.value} value={f.value} className="flex-none px-2">
                {f.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {filters.map((f) => {
            const rows =
              f.value === 'الكل'
                ? correspondence
                : correspondence.filter((c) => c.kind === f.value)

            return (
              <TabsContent key={f.value} value={f.value}>
                {/* Desktop: true ledger table */}
                <div className="hidden md:block">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[7.5rem]">رقم المعاملة</TableHead>
                        <TableHead>الموضوع</TableHead>
                        <TableHead className="w-[10rem]">الجهة</TableHead>
                        <TableHead className="w-[6rem]">التاريخ</TableHead>
                        <TableHead className="w-[7rem]">الأهمية</TableHead>
                        <TableHead className="w-[9rem]">الحالة</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {rows.map((item) => {
                        const Icon = kindIcon[item.kind]
                        return (
                          <TableRow key={item.id}>
                            <TableCell className="num font-mono text-xs text-muted-foreground">
                              {item.ref}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-start gap-2">
                                <Icon
                                  className={cn(
                                    'mt-0.5 size-4 shrink-0',
                                    item.kind === 'وارد'
                                      ? 'text-primary'
                                      : item.kind === 'صادر'
                                        ? 'text-warning'
                                        : 'text-muted-foreground',
                                  )}
                                />
                                <span className="font-medium text-pretty">
                                  {item.subject}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {item.party}
                            </TableCell>
                            <TableCell className="num font-mono text-xs text-muted-foreground">
                              {formatDate(item.date)}
                            </TableCell>
                            <TableCell>
                              <PriorityBadge priority={item.priority} />
                            </TableCell>
                            <TableCell>
                              <CorrespondenceStatusBadge status={item.status} />
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </div>

                {/* Mobile: stacked records with a status rail */}
                <ul className="flex flex-col divide-y divide-border md:hidden">
                  {rows.map((item) => {
                    const Icon = kindIcon[item.kind]
                    return (
                      <li key={item.id} className="flex gap-3 py-3 first:pt-0">
                        <span
                          aria-hidden="true"
                          className={cn(
                            'mt-1 w-[3px] shrink-0 self-stretch rounded-full',
                            item.priority === 'عاجل'
                              ? 'bg-destructive'
                              : item.priority === 'مرتفع'
                                ? 'bg-accent'
                                : 'bg-border',
                          )}
                        />
                        <div className="flex min-w-0 flex-1 flex-col gap-1.5">
                          <div className="flex items-center gap-2">
                            <Icon className="size-3.5 shrink-0 text-muted-foreground" />
                            <span className="num font-mono text-[0.6875rem] text-muted-foreground">
                              {item.ref}
                            </span>
                            <span className="num ms-auto font-mono text-[0.6875rem] text-muted-foreground">
                              {formatDate(item.date)}
                            </span>
                          </div>
                          <p className="text-sm leading-relaxed font-medium text-pretty">
                            {item.subject}
                          </p>
                          <div className="flex flex-wrap items-center gap-1.5">
                            <CorrespondenceStatusBadge status={item.status} />
                            <PriorityBadge priority={item.priority} />
                            <span className="truncate text-xs text-muted-foreground">
                              {item.party}
                            </span>
                          </div>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              </TabsContent>
            )
          })}
        </Tabs>
      </CardContent>
    </Card>
  )
}
