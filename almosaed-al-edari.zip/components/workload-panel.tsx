import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { departmentLoad } from '@/lib/data'

export function WorkloadPanel() {
  const max = Math.max(...departmentLoad.map((d) => d.total))

  return (
    <Card>
      <CardHeader>
        <CardTitle>توزيع العمل على الإدارات</CardTitle>
        <CardDescription>المهام المفتوحة مقابل الإجمالي المكلّف</CardDescription>
      </CardHeader>

      <CardContent>
        <ul className="flex flex-col gap-3.5">
          {departmentLoad.map((dept) => (
            <li key={dept.name} className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-xs font-medium">{dept.name}</span>
                <span className="num shrink-0 font-mono text-[0.6875rem] text-muted-foreground">
                  {dept.open} / {dept.total}
                </span>
              </div>
              <div
                className="relative h-2 w-full overflow-hidden rounded-full bg-muted"
                role="img"
                aria-label={`${dept.name}: ${dept.open} مهام مفتوحة من ${dept.total}`}
              >
                <span
                  className="absolute inset-y-0 start-0 rounded-full bg-chart-4/45"
                  style={{ width: `${(dept.total / max) * 100}%` }}
                />
                <span
                  className="absolute inset-y-0 start-0 rounded-full bg-primary"
                  style={{ width: `${(dept.open / max) * 100}%` }}
                />
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex items-center gap-4 border-t border-border pt-3">
          <span className="flex items-center gap-1.5 text-[0.6875rem] text-muted-foreground">
            <span className="size-2 rounded-full bg-primary" />
            مفتوحة
          </span>
          <span className="flex items-center gap-1.5 text-[0.6875rem] text-muted-foreground">
            <span className="size-2 rounded-full bg-chart-4/45" />
            الإجمالي
          </span>
        </div>
      </CardContent>
    </Card>
  )
}
