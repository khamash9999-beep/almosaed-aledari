import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import type {
  CorrespondenceStatus,
  Priority,
  RequestStatus,
  TaskStatus,
} from '@/lib/data'

/**
 * Status colours come from scheme-aware tokens only.
 * The `dark` variant in this project is class-based, so it never fires under
 * `prefers-color-scheme: dark`. Tokens (--warning, --destructive, --primary)
 * flip in both paths, so no `dark:` utilities are used here.
 *
 * warning = needs attention · primary = in motion · muted = settled
 * destructive = blocked / rejected
 */

const ATTENTION = 'bg-warning-surface text-warning'
const IN_MOTION = 'bg-primary/12 text-primary'
const BLOCKED = 'bg-destructive/12 text-destructive'
const SETTLED = 'bg-muted text-muted-foreground'

export function PriorityBadge({ priority }: { priority: Priority }) {
  if (priority === 'عاجل') {
    return <Badge className={BLOCKED}>{priority}</Badge>
  }
  if (priority === 'مرتفع') {
    return <Badge className={ATTENTION}>{priority}</Badge>
  }
  return <Badge variant="outline">{priority}</Badge>
}

export function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const styles: Record<TaskStatus, string> = {
    منجزة: IN_MOTION,
    'قيد التنفيذ': 'bg-secondary text-secondary-foreground',
    متأخرة: BLOCKED,
    'لم تبدأ': SETTLED,
  }
  return <Badge className={cn(styles[status])}>{status}</Badge>
}

export function CorrespondenceStatusBadge({
  status,
}: {
  status: CorrespondenceStatus
}) {
  const styles: Record<CorrespondenceStatus, string> = {
    'بانتظار التوقيع': ATTENTION,
    محوّلة: IN_MOTION,
    مؤرشفة: SETTLED,
    مرتجعة: BLOCKED,
  }
  return <Badge className={cn(styles[status])}>{status}</Badge>
}

export function RequestStatusBadge({ status }: { status: RequestStatus }) {
  const styles: Record<RequestStatus, string> = {
    'بانتظار الاعتماد': ATTENTION,
    معتمدة: IN_MOTION,
    مرفوضة: BLOCKED,
  }
  return <Badge className={cn(styles[status])}>{status}</Badge>
}
