import { CalendarClock, ChevronLeft } from 'lucide-react'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { PriorityBadge, TaskStatusBadge } from '@/components/status-badge'
import { tasks, formatDate } from '@/lib/data'

function initials(name: string) {
  return name
    .split(' ')
    .slice(0, 2)
    .map((part) => part[0])
    .join(' ')
}

export function TasksPanel() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>المهام الجارية</CardTitle>
        <CardDescription>مهام مكتب الإدارة المكلّف بها هذا الأسبوع</CardDescription>
        <CardAction>
          <Button variant="ghost" size="sm">
            الكل
            <ChevronLeft data-icon="inline-end" />
          </Button>
        </CardAction>
      </CardHeader>

      <CardContent>
        <ul className="flex flex-col divide-y divide-border">
          {tasks.map((task) => (
            <li key={task.id} className="flex flex-col gap-2.5 py-3.5 first:pt-0 last:pb-0">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 flex-col gap-1">
                  <span className="num font-mono text-[0.6875rem] text-muted-foreground">
                    {task.ref}
                  </span>
                  <h3 className="text-sm leading-relaxed font-medium text-pretty">
                    {task.title}
                  </h3>
                </div>
                <TaskStatusBadge status={task.status} />
              </div>

              <div className="flex items-center gap-2">
                <Progress value={task.progress} className="h-1.5 flex-1" />
                <span className="num shrink-0 font-mono text-[0.6875rem] text-muted-foreground">
                  {task.progress}%
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
                <div className="flex items-center gap-1.5">
                  <Avatar className="size-5">
                    <AvatarFallback className="bg-secondary text-[0.5625rem] text-secondary-foreground">
                      {initials(task.assignee)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground">
                    {task.assignee}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground">
                  {task.department}
                </span>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <CalendarClock className="size-3.5" />
                  <span className="num font-mono text-[0.6875rem]">
                    {formatDate(task.due)}
                  </span>
                </div>
                <span className="ms-auto">
                  <PriorityBadge priority={task.priority} />
                </span>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
