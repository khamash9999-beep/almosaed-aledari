import { ArrowUpRight, ArrowDownRight } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { stats } from '@/lib/data'

export function StatCards() {
  return (
    <section aria-label="مؤشرات سريعة">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((stat) => {
          const Arrow = stat.trend === 'up' ? ArrowUpRight : ArrowDownRight
          return (
            <Card key={stat.id} className="gap-0 py-4">
              <CardHeader className="px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground">
                  {stat.label}
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4">
                <div className="flex items-end justify-between gap-2">
                  <span className="num font-mono text-2xl leading-none font-semibold tracking-tight lg:text-3xl">
                    {stat.value}
                  </span>
                  <span
                    className={cn(
                      'num flex items-center gap-0.5 font-mono text-xs',
                      stat.trend === 'up' ? 'text-warning' : 'text-primary',
                    )}
                  >
                    <Arrow className="size-3" />
                    {stat.delta}
                  </span>
                </div>
                <p className="mt-2 text-[0.6875rem] leading-relaxed text-muted-foreground">
                  {stat.caption}
                </p>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </section>
  )
}
