'use client'

import { useState } from 'react'
import { Check, X } from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Empty, EmptyDescription, EmptyHeader, EmptyTitle } from '@/components/ui/empty'
import { RequestStatusBadge } from '@/components/status-badge'
import { requests as seedRequests, type RequestStatus } from '@/lib/data'

function initials(name: string) {
  return name
    .split(' ')
    .slice(0, 2)
    .map((part) => part[0])
    .join(' ')
}

export function RequestsPanel() {
  const [items, setItems] = useState(seedRequests)

  function decide(id: string, status: RequestStatus) {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status } : item)),
    )
  }

  const pending = items.filter((i) => i.status === 'بانتظار الاعتماد')

  return (
    <Card>
      <CardHeader>
        <CardTitle>طلبات بانتظار الاعتماد</CardTitle>
        <CardDescription>
          {pending.length > 0
            ? `${pending.length} طلبات تحتاج قراراً منك`
            : 'لا توجد طلبات معلّقة'}
        </CardDescription>
      </CardHeader>

      <CardContent>
        {pending.length === 0 ? (
          <Empty className="border-0 py-6">
            <EmptyHeader>
              <EmptyTitle>تم إنهاء جميع الطلبات</EmptyTitle>
              <EmptyDescription>
                لا توجد طلبات معلّقة على مكتبك حالياً.
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <ul className="flex flex-col divide-y divide-border">
            {pending.map((item) => (
              <li
                key={item.id}
                className="flex flex-col gap-2.5 py-3.5 first:pt-0 last:pb-0"
              >
                <div className="flex items-start gap-2.5">
                  <Avatar className="size-8">
                    <AvatarFallback className="bg-secondary text-xs text-secondary-foreground">
                      {initials(item.employee)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <span className="truncate text-sm font-medium">
                      {item.employee}
                    </span>
                    <span className="truncate text-xs text-muted-foreground">
                      {item.role}
                    </span>
                  </div>
                  <span className="shrink-0 text-[0.6875rem] text-muted-foreground">
                    {item.submitted}
                  </span>
                </div>

                <div className="flex flex-col gap-0.5 rounded-md bg-muted/60 px-2.5 py-2">
                  <span className="text-xs font-medium">{item.type}</span>
                  <span className="text-xs text-muted-foreground">
                    {item.detail}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => decide(item.id, 'معتمدة')}
                  >
                    <Check data-icon="inline-start" />
                    اعتماد
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => decide(item.id, 'مرفوضة')}
                  >
                    <X data-icon="inline-start" />
                    رفض
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}

        {items.some((i) => i.status !== 'بانتظار الاعتماد') && (
          <div className="mt-4 flex flex-col gap-2 border-t border-border pt-3">
            <p className="text-[0.6875rem] font-medium tracking-wide text-muted-foreground">
              قرارات حديثة
            </p>
            {items
              .filter((i) => i.status !== 'بانتظار الاعتماد')
              .map((item) => (
                <div key={item.id} className="flex items-center gap-2">
                  <span className="min-w-0 flex-1 truncate text-xs">
                    <span className="font-medium">{item.employee}</span>
                    <span className="text-muted-foreground"> — {item.type}</span>
                  </span>
                  <RequestStatusBadge status={item.status} />
                </div>
              ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
