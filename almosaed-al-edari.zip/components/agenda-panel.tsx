import { MapPin, Users, Video } from 'lucide-react'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { meetings } from '@/lib/data'

export function AgendaPanel() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>أجندة اليوم</CardTitle>
        <CardDescription>الخميس، 06 أغسطس 2026</CardDescription>
        <CardAction>
          <Button variant="ghost" size="sm">
            التقويم
          </Button>
        </CardAction>
      </CardHeader>

      <CardContent>
        <ol className="flex flex-col">
          {meetings.map((meeting, index) => (
            <li key={meeting.id} className="flex gap-3">
              {/* timeline rail */}
              <div className="flex flex-col items-center">
                <span className="num pt-0.5 font-mono text-xs font-medium text-muted-foreground">
                  {meeting.time}
                </span>
                <span
                  aria-hidden="true"
                  className="mt-1.5 size-2 shrink-0 rounded-full border-2 border-primary bg-background"
                />
                {index < meetings.length - 1 && (
                  <span
                    aria-hidden="true"
                    className="w-px flex-1 bg-border"
                  />
                )}
              </div>

              <div className="flex min-w-0 flex-1 flex-col gap-1.5 pb-4">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-sm leading-relaxed font-medium text-pretty">
                    {meeting.title}
                  </h3>
                  <Badge variant="outline" className="shrink-0">
                    {meeting.kind}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    {meeting.room === 'عن بُعد' ? (
                      <Video className="size-3.5" />
                    ) : (
                      <MapPin className="size-3.5" />
                    )}
                    {meeting.room}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="size-3.5" />
                    <span className="num font-mono">{meeting.attendees}</span>
                  </span>
                  <span className="num font-mono">{meeting.duration}</span>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </CardContent>
    </Card>
  )
}
