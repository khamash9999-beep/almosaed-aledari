'use client'

import {
  LayoutDashboard,
  ListChecks,
  Mails,
  FileCheck2,
  CalendarDays,
  Users,
  Archive,
  Settings,
  LifeBuoy,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'

const primaryNav = [
  { label: 'لوحة التحكم', icon: LayoutDashboard, active: true },
  { label: 'المهام', icon: ListChecks, count: 34 },
  { label: 'المعاملات والبريد', icon: Mails, count: 12 },
  { label: 'الطلبات', icon: FileCheck2, count: 9 },
  { label: 'التقويم والاجتماعات', icon: CalendarDays },
  { label: 'الموظفون', icon: Users },
  { label: 'الأرشيف', icon: Archive },
]

const secondaryNav = [
  { label: 'الإعدادات', icon: Settings },
  { label: 'المساعدة والدعم', icon: LifeBuoy },
]

export function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex items-center gap-3 px-4 py-4">
        <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-sidebar-primary font-mono text-sm font-semibold text-sidebar-primary-foreground">
          إد
        </div>
        <div className="flex min-w-0 flex-col">
          <span className="truncate text-sm font-semibold">
            المساعد الإداري
          </span>
          <span className="truncate text-xs text-sidebar-foreground/60">
            الإدارة العامة
          </span>
        </div>
      </div>

      <Separator className="bg-sidebar-border" />

      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto p-3">
        <p className="px-2 pb-1 text-[0.6875rem] font-medium tracking-wide text-sidebar-foreground/45">
          العمل اليومي
        </p>
        {primaryNav.map((item) => (
          <button
            key={item.label}
            type="button"
            onClick={onNavigate}
            aria-current={item.active ? 'page' : undefined}
            className={cn(
              'group relative flex items-center gap-2.5 rounded-md py-2 pe-2.5 ps-3.5 text-start text-sm transition-colors',
              'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
              'focus-visible:ring-2 focus-visible:ring-sidebar-ring focus-visible:outline-none',
              item.active
                ? 'bg-sidebar-accent font-medium text-sidebar-accent-foreground'
                : 'text-sidebar-foreground/75',
            )}
          >
            {/* signature element: brass spine marking the active record */}
            <span
              aria-hidden="true"
              className={cn(
                'absolute inset-y-1.5 start-0 w-[3px] rounded-full bg-sidebar-primary transition-opacity',
                item.active ? 'opacity-100' : 'opacity-0',
              )}
            />
            <item.icon className="size-4 shrink-0" />
            <span className="min-w-0 flex-1 truncate">{item.label}</span>
            {item.count ? (
              <span className="num shrink-0 rounded bg-sidebar-foreground/10 px-1.5 py-0.5 font-mono text-[0.6875rem] text-sidebar-foreground/70">
                {item.count}
              </span>
            ) : null}
          </button>
        ))}

        <Separator className="my-3 bg-sidebar-border" />

        {secondaryNav.map((item) => (
          <button
            key={item.label}
            type="button"
            onClick={onNavigate}
            className="flex items-center gap-2.5 rounded-md py-2 pe-2.5 ps-3.5 text-start text-sm text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 focus-visible:ring-sidebar-ring focus-visible:outline-none"
          >
            <item.icon className="size-4 shrink-0" />
            <span className="truncate">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-3">
        <div className="rounded-md border border-sidebar-border bg-sidebar-accent/40 p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium">دورة الأرشفة</span>
            <Badge
              variant="outline"
              className="border-sidebar-primary/40 text-sidebar-primary"
            >
              نشطة
            </Badge>
          </div>
          <p className="mt-1.5 text-xs leading-relaxed text-sidebar-foreground/60">
            آخر مزامنة للأرشيف الإلكتروني اليوم 08:20 صباحاً
          </p>
        </div>
      </div>
    </div>
  )
}
