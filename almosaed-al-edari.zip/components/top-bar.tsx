'use client'

import { useState } from 'react'
import { Menu, Search, Bell, Plus, ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { SidebarNav } from '@/components/sidebar-nav'

export function TopBar() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="flex h-14 items-center gap-2 px-3 sm:px-5">
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger
            render={
              <Button variant="ghost" size="icon-sm" className="lg:hidden" />
            }
          >
            <Menu />
            <span className="sr-only">فتح قائمة التنقل</span>
          </SheetTrigger>
          <SheetContent side="right" className="w-72 p-0" showCloseButton={false}>
            <SheetTitle className="sr-only">قائمة التنقل الرئيسية</SheetTitle>
            <SidebarNav onNavigate={() => setMenuOpen(false)} />
          </SheetContent>
        </Sheet>

        <div className="flex min-w-0 flex-1 items-center gap-2">
          <div className="relative hidden min-w-0 flex-1 md:block md:max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 start-2.5 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="ابحث برقم المعاملة أو الموضوع…"
              aria-label="بحث"
              className="ps-8"
            />
          </div>
          <span className="truncate text-sm font-medium md:hidden">
            لوحة التحكم
          </span>
        </div>

        <Button variant="ghost" size="icon-sm" className="md:hidden">
          <Search />
          <span className="sr-only">بحث</span>
        </Button>

        <Button variant="ghost" size="icon-sm" className="relative">
          <Bell />
          <span
            aria-hidden="true"
            className="absolute top-1 end-1 size-1.5 rounded-full bg-accent"
          />
          <span className="sr-only">التنبيهات — 4 غير مقروءة</span>
        </Button>

        <Button size="sm" className="hidden sm:inline-flex">
          <Plus data-icon="inline-start" />
          معاملة جديدة
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger
            render={
              <Button variant="ghost" size="sm" className="gap-2 px-1.5" />
            }
          >
            <Avatar className="size-7">
              <AvatarFallback className="bg-primary text-xs text-primary-foreground">
                ف م
              </AvatarFallback>
            </Avatar>
            <span className="hidden text-sm font-medium lg:inline">
              فهد المطيري
            </span>
            <ChevronDown className="hidden size-3.5 text-muted-foreground lg:inline" />
            <span className="sr-only">قائمة الحساب</span>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <div className="px-2 py-1.5">
              <p className="text-sm font-medium">فهد المطيري</p>
              <p className="text-xs text-muted-foreground">
                مدير المكتب الإداري
              </p>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem>الملف الشخصي</DropdownMenuItem>
              <DropdownMenuItem>التفويض والصلاحيات</DropdownMenuItem>
              <DropdownMenuItem>إعدادات التنبيهات</DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem variant="destructive">
                تسجيل الخروج
              </DropdownMenuItem>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
